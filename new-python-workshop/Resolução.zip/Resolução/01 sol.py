x = float(input("x = "))
y = float(input("y = "))

soma = x + y
diferenca = x - y
produto = x * y

print(f"Soma: {soma}")
print(f"Diferença: {diferenca}")
print(f"Produto: {produto}")
