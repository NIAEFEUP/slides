import random

chute = int(input("Chute um número: "))

escolhido = random.randint(0, 100)

count = 1

while (chute != escolhido):
  if chute > escolhido:
    print(f"O número {chute} é maior")
  else:
    print(f"O número {chute} é menor")
  count += 1
  print()
  chute = int(input("Chute um número: "))


print(f"Acertaste em {count} tentativas!")
  
