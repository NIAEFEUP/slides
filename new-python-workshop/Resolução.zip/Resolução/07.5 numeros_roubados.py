# Você é um detetive contratado para investigar o sumiço de alguns números preciosos de uma coleção muito rara. A lista continha números entre 1 e 10, mas misteriosamente alguns desapareceram!
# O seu trabalho é:
# 1. Analisar quais números estão faltando.
# 2. Verificar se há algum número suspeito que aparece mais de uma vez.
# 3. Dizer se a soma total dos números ainda presentes é par ou ímpar.
# 4. Classificar os números restantes como:
#    - Pequenos (1 a 3),
#    - Médios (4 a 7),
#    - Grandes (8 a 10)
# Requisitos técnicos
# - Usar listas para representar os números encontrados na cena.
# - Utilizar loops para análise.
# - Utilizar condições para classificar os números e identificar suspeitas.
# - Utilizar funções auxiliares se quiser modularizar.
colecao_encontrada = [1, 2, 3, 5, 5, 7, 9, 10]

# 1 e 2
numFalta = []
numRepete = []
for i in range(1, 11):
  if colecao_encontrada.count(i) == 0:
    numFalta.append(i)
  elif colecao_encontrada.count(i) > 1:
    numRepete.append(i)

print(f"Números que faltam: {numFalta}")
print(f"Números suspeitos: {numRepete}")

# 3
soma = sum(colecao_encontrada)
if(soma % 2 == 0):
  print(f"A soma {soma} é par")
else:
  print(f"A soma {soma} é impar")

print()
print("Classificação:")

# 4
tamanhos = [[], [], []]
for i in colecao_encontrada:
  if(i >= 1 and i <= 3):
    tamanhos[0].append(i)
  elif (i >= 4 and i <= 7):
    tamanhos[1].append(i)
  else:
    tamanhos[2].append(i)
  
print(f"Pequenos {tamanhos[0]}")
print(f"Medios {tamanhos[1]}")
print(f"Grandes {tamanhos[2]}")