frase = "BemvindosaoWoRksHop!"

contador = 0

for caracter in frase:
    if caracter.islower():
        contador += 1

print(f"O número de letras minúsculas é {contador}")