n = int(input("digite: "))

for num in range(n):
  if(num % 3 == 0 and num % 5 == 0):
    print(f"fizzbuzz")
  elif(num % 3 == 0):
    print(f"fizz")
  elif(num % 5 == 0):
    print(f"buzz")
  else:
    print(num)

