# Lista fornecida via código ou input
colecao_encontrada = [1, 2, 3, 5, 5, 7, 9, 10]  

# 1. Identificar números faltando


# 2. Identificar duplicatas


# 3. Soma e par/ímpar


# 4. Classificar por tamanho

